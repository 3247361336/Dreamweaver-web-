<?php
// database host
$db_host   = "localhost:3306";

// database name
$db_name   = "shop";

// database username
$db_user   = "root";

// database password
$db_pass   = "";

// table prefix
$prefix    = "ecs_";

$timezone    = "Asia/Shanghai";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '');

define('STORE_KEY','4659eefdfb9dda8f281188febb2ca07c');

?>